#03_05
linearMod<- lm(Cash ~ EBITDA, data=X03_05_Start_R)
print(linearMod)






